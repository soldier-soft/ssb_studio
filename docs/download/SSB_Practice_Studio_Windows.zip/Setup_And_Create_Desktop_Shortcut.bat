@echo off
setlocal enabledelayedexpansion
title SSB Practice Studio - Desktop Shortcut Setup (Developed by Lt. V. Elangovan)
cls
echo =======================================================================
echo          SSB PRACTICE STUDIO - 1-CLICK DESKTOP SHORTCUT SETUP
echo                 Developed by Lt. V. Elangovan
echo =======================================================================
echo.
echo  Detecting installation directory and Windows Desktop environment...
echo.

set "SCRIPT_DIR=%~dp0"
set "EXE_PATH=%SCRIPT_DIR%SSBPracticeStudio\SSBPracticeStudio.exe"
set "ICON_PATH=%SCRIPT_DIR%SSBPracticeStudio\_internal\assets\app_icon.ico"

if not exist "%EXE_PATH%" (
    if exist "%SCRIPT_DIR%SSBPracticeStudio.exe" (
        set "EXE_PATH=%SCRIPT_DIR%SSBPracticeStudio.exe"
        set "ICON_PATH=%SCRIPT_DIR%_internal\assets\app_icon.ico"
    )
)

if not exist "%EXE_PATH%" (
    echo [ERROR] SSBPracticeStudio.exe was not found!
    echo Please make sure you unzipped the full archive before running this script.
    echo.
    pause
    exit /b 1
)

if not exist "%ICON_PATH%" (
    set "ICON_PATH=%EXE_PATH%"
)

echo  Creating Windows Desktop Shortcut with embedded high-res icon...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$WshShell = New-Object -ComObject WScript.Shell; " ^
    "$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop); " ^
    "$ShortcutPath = Join-Path -Path $DesktopPath -ChildPath 'SSB Practice Studio.lnk'; " ^
    "$Shortcut = $WshShell.CreateShortcut($ShortcutPath); " ^
    "$Shortcut.TargetPath = '%EXE_PATH%'; " ^
    "$Shortcut.WorkingDirectory = (Split-Path -Parent '%EXE_PATH%'); " ^
    "$Shortcut.IconLocation = '%ICON_PATH%,0'; " ^
    "$Shortcut.Description = 'SSB Practice Studio - Officer Assessment Psychological Tests (Developed by Lt. V. Elangovan)'; " ^
    "$Shortcut.Save(); " ^
    "Write-Host '[SUCCESS] Desktop shortcut created at:' $ShortcutPath -ForegroundColor Green"

echo.
echo =======================================================================
echo   SETUP COMPLETED SUCCESSFULLY!
echo   Launching SSB Practice Studio now...
echo   Developed by Lt. V. Elangovan
echo =======================================================================
echo.
start "" "%EXE_PATH%"
timeout /t 3 >nul
exit /b 0
