=======================================================================
               SSB PRACTICE STUDIO — 100% OFFLINE PREPARATION
                       Developed by Lt. V. Elangovan
=======================================================================

Thank you for downloading SSB Practice Studio!
Engineered specifically for Indian Armed Forces Aspirants (NDA, CDS, AFCAT, SSB Interviews).

QUICK 3-STEP SETUP:
-------------------
1. Extract all contents of this ZIP archive to any folder (e.g. C:\SSB_Studio or Downloads).
2. Double-click:
   --> Setup_And_Create_Desktop_Shortcut.bat
3. A shortcut named 'SSB Practice Studio' will instantly be placed on your
   Windows Desktop with the official application icon, and the app will open!

KEY FEATURES:
-------------
- 100% Offline & Private: No internet connection required. All practice data and scores stay on your device.
- WAT (Word Association Test): Realistic 15-second timer with automatic slide transitions.
- SRT (Situation Reaction Test): 30-second pacing or 30-minute exam mode, natural 1-60 ordering, '( ... )' endings.
- TAT (Thematic Apperception Test): 30s viewing phase followed by 4min writing, blank slide #12 support.
- Custom Import: Easily load your coaching notes, PDFs, Word documents, text lists, or image folders.
- Performance Analytics: Comprehensive response speed, character density, and PDF export reports.

SYSTEM REQUIREMENTS:
--------------------
- OS: Windows 10 or Windows 11 (64-bit)
- RAM: 2 GB minimum

CREDITS & DEVELOPER:
-------------------
Developed by Lt. V. Elangovan
Official Repository: https://github.com/soldier-soft/ssb_studio
Live Web Portal:    https://soldier-soft.github.io/ssb_studio/
=======================================================================
